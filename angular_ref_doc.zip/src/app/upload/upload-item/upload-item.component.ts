import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-upload-item',
  templateUrl: './upload-item.component.html',
  styleUrls: ['./upload-item.component.css']
})
export class UploadItemComponent implements OnInit {

  @Input()
  fileName: string;

  @Input()
  fileSize: number;

  @Input()
  uploadProgress: number;

  constructor() { }

  ngOnInit() {
  }

}
