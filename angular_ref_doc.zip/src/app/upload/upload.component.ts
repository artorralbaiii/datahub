import { Component, OnInit } from '@angular/core';
import { Upload } from '../upload/upload';
import * as _ from 'lodash';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  currentUpload: Upload;
  dropzoneActive: boolean = false;
  files: File[] = [];
  uplLabel = 'Drop a file here or click to Upload';

  constructor() { }

  ngOnInit() {
  }

  dropzoneState($event: boolean) {
    this.dropzoneActive = $event;
  }

  handleDrop(fileList: FileList) {
    let filesIndex = _.range(fileList.length);

    _.each(filesIndex, (idx) => {
      this.files.push(fileList[idx]);
    });

  }

  onFileChange($event: any) {
    let fileList: FileList = $event.target.files;
    let filesIndex = _.range($event.target.files.length);

    _.each(filesIndex, (idx) => {
      this.files.push(fileList[idx]);
    });
  }

  openFileBrowser($event: any) {
    $event.preventDefault();

    let element: HTMLElement = document.getElementById('fileBrowserControl') as HTMLElement;
    element.click();
  }

}
