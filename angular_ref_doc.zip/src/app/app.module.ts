import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { HeaderComponent } from './layout/header/header.component';
import { UploadComponent } from './upload/upload.component';

import { FileDropDirective } from './upload/file-drop.directive';

import { FileSizePipe } from './upload/filesize.pipe';
import { UploadItemComponent } from './upload/upload-item/upload-item.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    UploadComponent,

    FileDropDirective,

    FileSizePipe,

    UploadItemComponent
  ],
  imports: [
    BrowserModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
